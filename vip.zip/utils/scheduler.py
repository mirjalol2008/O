from apscheduler.schedulers.asyncio import AsyncIOScheduler
from db.database import get_all_subscriptions
import datetime

async def check_subscriptions(app):
    all_subs = get_all_subscriptions()
    now = datetime.datetime.now()

    for user_id, start_time_str, duration_days in all_subs:
        start_time = datetime.datetime.fromisoformat(start_time_str)
        end_time = start_time + datetime.timedelta(days=duration_days)

        if now >= end_time:
            try:
                await app.bot.ban_chat_member(chat_id='@AKdgKK2JOXIyNDIy', user_id=user_id)
                await app.bot.unban_chat_member(chat_id='@AKdgKK2JOXIyNDIy', user_id=user_id)
                print(f"⛔ Foydalanuvchi {user_id} obunasi tugadi. Kanaldan chiqarildi.")
            except Exception as e:
                print(f"Xato: {e}")

async def start_scheduler(app):
    scheduler = AsyncIOScheduler()
    scheduler.add_job(check_subscriptions, "interval", minutes=10, args=[app])
    scheduler.start()