from telegram.ext import Application
from handlers.user import register_user_handlers
from utils.scheduler import start_scheduler
from config import BOT_TOKEN
from db.database import init_db

async def main():
    app = Application.builder().token(BOT_TOKEN).build()
    init_db()
    register_user_handlers(app)
    await start_scheduler(app)
    print("Bot ishga tushdi")
    await app.run_polling()

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())