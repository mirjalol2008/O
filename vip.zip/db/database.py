import sqlite3
import datetime

def init_db():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS subscriptions (
        user_id INTEGER PRIMARY KEY,
        start_time TEXT,
        duration_days INTEGER
    )''')
    conn.commit()
    conn.close()

def add_subscription(user_id, start_time, duration_days):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("REPLACE INTO subscriptions (user_id, start_time, duration_days) VALUES (?, ?, ?)",
              (user_id, start_time.isoformat(), duration_days))
    conn.commit()
    conn.close()

def get_all_subscriptions():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("SELECT user_id, start_time, duration_days FROM subscriptions")
    result = c.fetchall()
    conn.close()
    return result