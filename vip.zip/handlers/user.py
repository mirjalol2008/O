from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler
from config import ADMIN_ID
from db.database import add_subscription
import datetime

pending_users = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Assalomu alaykum!\n\nVIP kanalga kirish uchun to‘lov chekini yuboring.\nTo‘lov qilgach, rasmni yuboring."
    )

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    photo = update.message.photo[-1].file_id
    pending_users[user_id] = photo

    keyboard = [
        [
            InlineKeyboardButton("✅ Tasdiqlash", callback_data=f"approve_{user_id}"),
            InlineKeyboardButton("❌ Bekor qilish", callback_data=f"reject_{user_id}")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await context.bot.send_photo(
        chat_id=ADMIN_ID,
        photo=photo,
        caption=f"Yangi to‘lov chek!\nUser ID: {user_id}",
        reply_markup=reply_markup
    )
    await update.message.reply_text("To‘lov tekshirish uchun yuborildi. Iltimos, kuting.")

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    await query.answer()

    if not data.startswith("approve_") and not data.startswith("reject_"):
        return

    user_id = int(data.split("_")[1])
    if data.startswith("approve_"):
        start_time = datetime.datetime.now()
        add_subscription(user_id, start_time, 30)
        invite_link = f"https://t.me/+AKdgKK2JOXIyNDIy"

        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=f"✅ To‘lov tasdiqlandi!\nKanalga qo‘shiling: {invite_link}"
            )
        except:
            pass

        await query.edit_message_caption(
            caption=f"✅ Tasdiqlandi: {user_id}"
        )
    elif data.startswith("reject_"):
        try:
            await context.bot.send_message(chat_id=user_id, text="❌ To‘lov rad etildi.")
        except:
            pass
        await query.edit_message_caption(
            caption=f"❌ Rad etildi: {user_id}"
        )

def register_user_handlers(app: Application):
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(CallbackQueryHandler(handle_callback))